NOTE

both make and bash can be used to check my codes

use of bash
just uncomment the required question commands and run (in the terminal):
bash run.sh 


use of Makefile
just run (in the terminal): to run the q1
make q1   