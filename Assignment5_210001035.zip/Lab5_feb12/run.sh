#!/bin/bash

echo "Madhavs car"

g++ q1_Car_FloodFill_Bresenhem.cpp -o q1_Car_FloodFill_Bresenhem -lglut -lGLU -lGL
./q1_Car_FloodFill_Bresenhem

# g++ scanline.cpp -o scanline -lglut -lGLU -lGL
# ./scanline

# g++ bdryfill.cpp -o bdryfill -lglut -lGLU -lGL
# ./bdryfill


# g++ car2.cpp -o car2 -lglut -lGLU -lGL
# ./car2

# g++ q2_BusDrawing.cpp -o q2_BusDrawing -lglut -lGLU -lGL
# ./q2_BusDrawing

# g++ circleMidpt.cpp -o circleMidpt -lglut -lGLU -lGL
# ./circleMidpt

# g++ ff.cpp -o ff -lglut -lGLU -lGL
# ./ff