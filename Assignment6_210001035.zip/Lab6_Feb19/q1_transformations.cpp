#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;


/*
Sairaj R. Loke 210001035
CS352 Lab5 Q2

Note:
I have added an extra keyboard controlled interface for the transforms
*/



GLfloat vertex[][3] = {{-1,0}, {1, 0},{1, 2},{0,4},{-1,2}};
GLfloat PI_ = 3.14159 ;
int n = 5; // Number of vertex in the polygon

void drawPolygon() {
    glBegin(GL_POLYGON);
    for (int i = 0; i < n; i++)
        glVertex2fv(vertex[i]);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 1.0, 0.0); // Red color for the polygon
    drawPolygon();
    glFlush();
}

void translate(float dx, float dy) {
    for (int i = 0; i < n; i++) {
        vertex[i][0] += dx;
        vertex[i][1] += dy;
        cout<<vertex[i][0]<<" "<<vertex[i][1]<<endl;
    }
    glutPostRedisplay();
}

void rotate(float angle) {
    float theta = angle * (PI_ / 180.0);
    float tempX, tempY;
    for (int i = 0; i < n; i++) {
        tempX = vertex[i][0];
        tempY = vertex[i][1];
        vertex[i][0] = tempX * cos(theta) - tempY * sin(theta);
        vertex[i][1] = tempX * sin(theta) + tempY * cos(theta);
        cout<<vertex[i][0]<<" "<<vertex[i][1]<<endl;
    }
    glutPostRedisplay();  //https://www.opengl.org/resources/libraries/glut/spec3/node20.html  ,. 
    // The next iteration through glutMainLoop, the window's display callback will be called to redisplay the window's normal plane. 
}

void scale(float sx, float sy) {
    for (int i = 0; i < n; i++) {
        vertex[i][0] *= sx;
        vertex[i][1] *= sy;
        cout<<vertex[i][0]<<" "<<vertex[i][1]<<endl;
    }
    glutPostRedisplay();
}

void shear(float shx, float shy) {
    for (int i = 0; i < n; i++) {
        vertex[i][0] += shx * vertex[i][1];
        vertex[i][1] += shy * vertex[i][0];
        cout<<vertex[i][0]<<" "<<vertex[i][1]<<endl;
    }
    glutPostRedisplay();
}

void reflect(char dir) {
    if (dir == 'y'){
        for (int i = 0; i < n; i++)
        vertex[i][0] = -vertex[i][0];// y axis
    }
    else if (dir == 'x'){
        for (int i = 0; i < n; i++)
        vertex[i][1] = -vertex[i][1];// x axis
    }
    
        
    glutPostRedisplay();
}

void menu(int choice) {
    switch (choice) {
        case 1:
            translate(5, 0);
            break;
        case 2:
            translate(-5, 0);
            break;
        case 3:
            translate(0, 5);
            break;
        case 4:
            translate(0, -5);
            break;
        case 5:
            rotate(20);
            break;
        case 6:
            scale(2, 2);
            break;
        case 7:
            scale(0.5, 0.5);
            break;
        case 8:
            shear(0.5, 0);
            break;
        case 9:
            shear(0, 0.5);
            break;
        case 10:
            
            reflect('x');
            break;
        case 11:
            cout<<"Y";
            reflect('y');
            break;
        case 12:
            exit(0);
            break;

        
    }
}



int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 800);
    glutCreateWindow("2D Transformations");
    gluOrtho2D(-50, 50, -50, 50);
    glutDisplayFunc(display);

    int submenu = glutCreateMenu(menu);
    glutAddMenuEntry("TranslateX+", 1);
    glutAddMenuEntry("TranslateX-", 2);
    glutAddMenuEntry("TranslateY+", 3);
    glutAddMenuEntry("TranslateY-", 4);
    glutAddMenuEntry("Rotate", 5);
    glutAddMenuEntry("ScaleUp", 6);
    glutAddMenuEntry("ScaleDown", 7);
    glutAddMenuEntry("ShearX", 8);
    glutAddMenuEntry("ShearY", 9);
    glutAddMenuEntry("ReflectX", 10);
    glutAddMenuEntry("ReflectY", 11);

    glutCreateMenu(menu);
    glutAddSubMenu("Transformations", submenu);
    // glutAddMenuEntry("Exit", 6);
    glutAttachMenu(GLUT_RIGHT_BUTTON);

    glutMainLoop();

    
    return 0;
}