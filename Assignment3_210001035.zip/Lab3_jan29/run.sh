#!/bin/bash

echo "EventPoly.cpp"

# g++ q1lineDDA.cpp -o q1lineDDA -lglut -lGLU -lGL
# ./q1lineDDA

# g++ q2lineBresh.cpp -o q2lineBresh -lglut -lGLU -lGL
# ./q2lineBresh

g++ q3lineMid.cpp -o q3lineMid -lglut -lGLU -lGL
./q3lineMid