#!/bin/bash

echo "Sairaj's Transformations 

"

g++ q1_transformations.cpp -o q1_transformations -lglut -lGLU -lGL
./q1_transformations