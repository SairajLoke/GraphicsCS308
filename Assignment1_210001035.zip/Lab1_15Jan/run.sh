#!/bin/bash

echo "Sairaj Assigment"

g++ q3bicycle.cpp -o q3bicycle -lglut -lGLU -lGL
./q3bicycle

# g++ q1tree.cpp -o q1tree -lglut -lGLU -lGL
# ./q1tree

# g++ q2house.cpp -o q2house -lglut -lGLU -lGL
# ./q2house