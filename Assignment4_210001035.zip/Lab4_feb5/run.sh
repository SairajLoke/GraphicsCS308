#!/bin/bash

echo "Circle.cpp"

# g++ q3circleDDA.cpp -o q3circleDDA -lglut -lGLU -lGL
# ./q3circleDDA

g++ q1circleBresh.cpp -o q1circleBresh -lglut -lGLU -lGL
./q1circleBresh

# g++ q2circleMidpt.cpp -o q2circleMidpt -lglut -lGLU -lGL
# ./q2circleMidpt