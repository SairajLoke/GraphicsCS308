#!/bin/bash

echo "EventPoly.cpp"

g++ eventpoly.cpp -o eventpoly -lglut -lGLU -lGL
./eventpoly